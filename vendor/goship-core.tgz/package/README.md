# `@goship/core`

可拔插 Micro-SaaS SDK：能力抽象 + Null Object 降级 + Landing Schema + Plugin Registry。

## 安装（workspace）

```ts
import {
  useAuth,
  usePayment,
  trackEvent,
  AuthButton,
  CheckoutButton,
  isAuthEnabled,
  isAuthConfigured,
  isPluginEnabled,
  PLUGIN_REGISTRY,
} from "@goship/core";
```

子路径：`@goship/core/auth`、`/auth/server`、`/billing`、`/mail`、`/telemetry`、`/seo`、`/plugins`、`/landing`。

## Env（`getEnv` / `hasEnv`）

Client 与 Server 共用 `getEnv`。`NEXT_PUBLIC_*` 必须经 `env.ts` 内 **静态** `process.env.NEXT_PUBLIC_…` 映射表读取——动态 `process.env[name]` 在浏览器包里不会被 Next 内联，会导致 `isAuthConfigured()` 等 SSR/CSR 不一致（典型症状：`AuthButton` hydration failed）。新增 public Key 时同步补进该表。

## Auth

| API | 含义 |
|-----|------|
| `useAuth()` | 能力门面：`loginWithEmail` / `loginWithGoogle` / `signOut` / `user` — **禁止在 app 重写** |
| `AuthPanel` | Google + Magic Link 共用表面（Modal 与 `/login`） |
| `getAuthMethods()` | Hub：Google / Apple / 魔法链接 / 邮箱验证码 |
| `getAuthEntryMode()` | Hub：`modal` \| `link` |
| `isAuthEnabled()` | 恒 true（默认基建） |
| `isAuthConfigured()` | 是否有 Supabase URL + Anon Key → 能否发 magic link |
| `AuthButton` / 模版 `AuthSlot` | 入口模式读 Hub env；皮肤可改 `className` |
| `AuthModal` / `LoginForm` | 弹窗 / 表单（均走 AuthPanel） |
| `getCurrentUser`（server） | RSC / Route 读会话 |

## Payment

```tsx
"use client";
import { usePayment, CheckoutButton, useAsyncAction } from "@goship/core";

export function BuyButton() {
  const { isAvailable, pay } = usePayment();
  if (!isAvailable) return null;
  return (
    <CheckoutButton
      label="Subscribe"
      priceId="price_..." // from product catalog / API — not required in Hub
      metadata={{ type: "default" }}
      onBefore={async () => true}
    />
  );
}
```

缺 Stripe Key / 未启用 → `isAvailable === false`，不抛错。  
`priceId` 由业务代码传入（或可选的 `NEXT_PUBLIC_STRIPE_PRICE_ID` 回退）；Hub 不强制填 Price。  
支付后履约：Webhook → `runCheckoutFulfillmentPipeline` → `src/custom/fulfillment/`（见 `docs/LIFECYCLE_HOOKS.md`）。

## Click lifecycle

```tsx
const { execute, loading } = useAsyncAction({
  eventName: "my_action",
  onBefore: async () => true,
  action: async () => { /* ... */ },
  onSuccess: () => {},
});
```

## Telemetry

```ts
void trackEvent("user.signup", { plan: "pro" });
```

缺 `GOSHIP_TELEMETRY_KEY` / URL → 静默 no-op。

## Mail

`sendMail` / `SendTestMailForm` — 缺 `RESEND_API_KEY` → skip。

## Landing Schema

```ts
import {
  createDefaultLandingConfig,
  LANDING_THEMES,
  type LandingPageConfig,
} from "@goship/core";

const config = createDefaultLandingConfig({ name: "RonFax" });
// config.theme: "zinc" | "violet" | "emerald" | "sunset"
```

完整契约见 `docs/SLOT_HOOK_CONTRACT.md`、`docs/LANDING_CONFIG.md`。落地页皮肤在模版 `src/components/landing/`；业务在 `src/custom/`。

## Plugin Registry

```ts
import {
  PLUGIN_REGISTRY,
  isPluginEnabled,
  listAllowedSecretKeys,
  dualEnvBankKey,
} from "@goship/core";
```

Hub 能力卡片由注册表驱动。含 `deploy` 类（`github` / `vercel`：Hub 台账，子站无运行时依赖）。Stripe 等可声明 `dualEnv`（`STRIPE_MODE` + `__test`/`__live` 银行键）；子站仍只读 canonical `STRIPE_*`。加插件流程见 `docs/PLUGINS_GUIDE.md`。

## SEO

`getSiteProfile`、`listPublishedDocuments`（优先 Supabase `seo_documents`）、`buildMetadata` / `buildJsonLd`（Organization + BreadcrumbList + Article + FAQPage；支持 author / image / noindex）等 — 对齐 `docs/SEO_GEO_CONTRACT.md` v0.3.1。

`SeoActionType` 含 Hub 任务：`diagnose` | `seed_plan` | `generate` | `publish` | `index` | `refresh_gsc`（`seed_plan` = 0→1 无 GSC 拓词）。

`rowToSeoDocument` / `seoDocumentToRow` 用于 Hub ↔ DB 映射。模版 `content/blog` + `src/lib/blog.ts`：`listBlogPosts()` = DB ∪ 文件；`blogPostToSeoDocument` / `seoDocumentToBlogPost`。
## 降级铁律

- 缺环境变量 → return / skip / 隐藏 UI，**禁止**打断宿主页面  
- 业务页面向能力 API，不硬编码插件 id  

## 相关文档

- `docs/ARCHITECTURE.md`  
- `docs/PLUGINS_GUIDE.md`  
- `docs/LANDING_CONFIG.md`  
- `docs/HUB_GUIDE.md`  
