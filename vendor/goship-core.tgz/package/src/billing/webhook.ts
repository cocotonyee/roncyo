import { createHmac, timingSafeEqual } from "node:crypto";
import { getEnv, fail, ok, skipped, type PluginResult } from "../env";

export interface StripeWebhookEvent {
  id: string;
  type: string;
  data: { object: Record<string, unknown> };
}

export interface CheckoutFulfillmentContext {
  sessionId: string;
  customerEmail: string | null;
  amountTotal: number | null;
  currency: string | null;
  metadata: Record<string, string>;
  clientReferenceId: string | null;
  /** Raw Checkout Session object from Stripe */
  session: Record<string, unknown>;
}

export type FulfillmentHandler = (
  ctx: CheckoutFulfillmentContext,
) => Promise<void> | void;

export type FulfillmentHandlers = Record<string, FulfillmentHandler>;

function getWebhookSecret(): string | undefined {
  return getEnv("STRIPE_WEBHOOK_SECRET");
}

/**
 * Verify Stripe-Signature and parse event JSON.
 * Do not reimplement in apps — use this from `/api/billing/webhook`.
 */
export function parseStripeWebhookEvent(input: {
  rawBody: string;
  signatureHeader: string | null;
  /** Tolerance window in seconds (default 5 min) */
  toleranceSec?: number;
}): PluginResult<StripeWebhookEvent> {
  const secret = getWebhookSecret();
  if (!secret) {
    return skipped("STRIPE_WEBHOOK_SECRET not set");
  }

  if (!input.signatureHeader) {
    return fail("Missing Stripe-Signature header");
  }

  const parts: Record<string, string> = {};
  for (const piece of input.signatureHeader.split(",")) {
    const eq = piece.indexOf("=");
    if (eq <= 0) continue;
    const key = piece.slice(0, eq).trim();
    const value = piece.slice(eq + 1).trim();
    if (key) parts[key] = value;
  }

  const timestamp = parts.t;
  const v1 = parts.v1;
  if (!timestamp || !v1) {
    return fail("Invalid Stripe-Signature header");
  }

  const tolerance = input.toleranceSec ?? 300;
  const tsNum = Number(timestamp);
  if (!Number.isFinite(tsNum)) {
    return fail("Invalid webhook timestamp");
  }
  const age = Math.abs(Math.floor(Date.now() / 1000) - tsNum);
  if (age > tolerance) {
    return fail("Webhook timestamp outside tolerance");
  }

  const signedPayload = `${timestamp}.${input.rawBody}`;
  const expected = createHmac("sha256", secret)
    .update(signedPayload, "utf8")
    .digest("hex");

  try {
    const a = Buffer.from(expected, "utf8");
    const b = Buffer.from(v1, "utf8");
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      return fail("Webhook signature mismatch");
    }
  } catch {
    return fail("Webhook signature verification failed");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(input.rawBody) as unknown;
  } catch {
    return fail("Invalid webhook JSON");
  }

  if (
    typeof parsed !== "object" ||
    parsed === null ||
    !("type" in parsed) ||
    !("data" in parsed)
  ) {
    return fail("Unexpected webhook payload shape");
  }

  const event = parsed as StripeWebhookEvent;
  if (typeof event.type !== "string" || !event.data?.object) {
    return fail("Webhook event missing type/data.object");
  }

  return ok(event);
}

export function checkoutSessionToFulfillmentContext(
  session: Record<string, unknown>,
): CheckoutFulfillmentContext {
  const metadataRaw = session.metadata;
  const metadata: Record<string, string> = {};
  if (metadataRaw && typeof metadataRaw === "object") {
    for (const [key, value] of Object.entries(
      metadataRaw as Record<string, unknown>,
    )) {
      if (typeof value === "string") metadata[key] = value;
    }
  }

  const details = session.customer_details as
    | { email?: string | null }
    | undefined;

  return {
    sessionId: typeof session.id === "string" ? session.id : "",
    customerEmail:
      (typeof details?.email === "string" ? details.email : null) ??
      (typeof session.customer_email === "string"
        ? session.customer_email
        : null),
    amountTotal:
      typeof session.amount_total === "number" ? session.amount_total : null,
    currency: typeof session.currency === "string" ? session.currency : null,
    metadata,
    clientReferenceId:
      typeof session.client_reference_id === "string"
        ? session.client_reference_id
        : null,
    session,
  };
}

/**
 * Post-checkout pipeline: dispatch by `metadata.type` → custom fulfill handler.
 * Apps only register handlers in `src/custom/fulfillment` — never parse Stripe here.
 */
export async function runCheckoutFulfillmentPipeline(
  ctx: CheckoutFulfillmentContext,
  handlers: FulfillmentHandlers,
): Promise<{ handled: boolean; type: string }> {
  const type = ctx.metadata.type?.trim() || "default";
  const handler = handlers[type] ?? handlers.default;
  if (!handler) {
    return { handled: false, type };
  }
  await handler(ctx);
  return { handled: true, type };
}
