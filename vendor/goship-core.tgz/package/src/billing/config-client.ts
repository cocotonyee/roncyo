/**
 * Client-safe billing env reads (NEXT_PUBLIC_* only).
 */

export function getStripePublishableKey(): string | undefined {
  const value = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
  if (!value || value.trim() === "") return undefined;
  return value.trim();
}

export function getDefaultPriceId(): string | undefined {
  const value = process.env.NEXT_PUBLIC_STRIPE_PRICE_ID;
  if (!value || value.trim() === "") return undefined;
  return value.trim();
}

export function isBillingPublicConfigured(): boolean {
  // Price ID is optional — apps pass priceId from code / API at checkout time.
  return Boolean(getStripePublishableKey());
}
