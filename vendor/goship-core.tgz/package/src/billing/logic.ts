import { getEnv, hasEnv, fail, ok, skipped, type PluginResult } from "../env";

export function isBillingConfigured(): boolean {
  return hasEnv("STRIPE_SECRET_KEY", "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY");
}

export function getStripeSecretKey(): string | undefined {
  return getEnv("STRIPE_SECRET_KEY");
}

export function getStripePublishableKey(): string | undefined {
  return getEnv("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY");
}

export function getDefaultPriceId(): string | undefined {
  return getEnv("STRIPE_PRICE_ID") ?? getEnv("NEXT_PUBLIC_STRIPE_PRICE_ID");
}

export interface CheckoutInput {
  priceId: string;
  successUrl: string;
  cancelUrl: string;
  customerEmail?: string;
  clientReferenceId?: string;
  /** Business metadata — carried to webhook fulfillment via session.metadata */
  metadata?: Record<string, string>;
  /** Default: subscription. Use `payment` for one-shot products. */
  mode?: "subscription" | "payment";
}

export interface SubscriptionStatus {
  active: boolean;
  status: string | null;
  customerId: string | null;
  priceId: string | null;
  currentPeriodEnd: string | null;
}

/**
 * Creates a Stripe Checkout Session (subscription mode).
 * Missing STRIPE_SECRET_KEY → silent skip (never throws to host SaaS).
 */
export async function createCheckoutSession(
  input: CheckoutInput,
): Promise<PluginResult<{ url: string; sessionId: string }>> {
  const secret = getStripeSecretKey();
  if (!secret) {
    return skipped("STRIPE_SECRET_KEY not set");
  }

  if (!input.priceId || !input.successUrl || !input.cancelUrl) {
    return fail("priceId, successUrl, and cancelUrl are required");
  }

  try {
    const mode = input.mode ?? "subscription";
    const body = new URLSearchParams();
    body.set("mode", mode);
    body.set("success_url", input.successUrl);
    body.set("cancel_url", input.cancelUrl);
    body.set("line_items[0][price]", input.priceId);
    body.set("line_items[0][quantity]", "1");
    body.set("allow_promotion_codes", "true");

    if (input.customerEmail) {
      body.set("customer_email", input.customerEmail);
    }
    if (input.clientReferenceId) {
      body.set("client_reference_id", input.clientReferenceId);
    }
    if (input.metadata) {
      for (const [key, value] of Object.entries(input.metadata)) {
        body.set(`metadata[${key}]`, value);
        // Mirror onto subscription for subscription mode webhooks
        if (mode === "subscription") {
          body.set(`subscription_data[metadata][${key}]`, value);
        }
      }
    }

    const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secret}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body,
    });

    const json: unknown = await response.json();

    if (!response.ok) {
      const message = extractStripeError(json) ?? `Stripe HTTP ${response.status}`;
      return fail(message);
    }

    const session = json as { id?: string; url?: string | null };
    if (!session.id || !session.url) {
      return fail("Stripe session missing id/url");
    }

    return ok({ url: session.url, sessionId: session.id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Checkout failed";
    return fail(message);
  }
}

/**
 * Lightweight subscription probe via Stripe Customer email search.
 * Prefer storing customer/subscription IDs in your DB for production.
 */
export async function getSubscriptionStatusByEmail(
  email: string,
): Promise<PluginResult<SubscriptionStatus>> {
  const secret = getStripeSecretKey();
  if (!secret) {
    return skipped("STRIPE_SECRET_KEY not set");
  }

  if (!email.trim()) {
    return fail("email is required");
  }

  try {
    const customerRes = await fetch(
      `https://api.stripe.com/v1/customers?email=${encodeURIComponent(email)}&limit=1`,
      {
        headers: { Authorization: `Bearer ${secret}` },
      },
    );
    const customerJson: unknown = await customerRes.json();
    if (!customerRes.ok) {
      return fail(extractStripeError(customerJson) ?? "Customer lookup failed");
    }

    const customers = (customerJson as { data?: { id: string }[] }).data ?? [];
    const customer = customers[0];
    if (!customer) {
      return ok({
        active: false,
        status: null,
        customerId: null,
        priceId: null,
        currentPeriodEnd: null,
      });
    }

    const subRes = await fetch(
      `https://api.stripe.com/v1/subscriptions?customer=${customer.id}&limit=1&status=all`,
      {
        headers: { Authorization: `Bearer ${secret}` },
      },
    );
    const subJson: unknown = await subRes.json();
    if (!subRes.ok) {
      return fail(extractStripeError(subJson) ?? "Subscription lookup failed");
    }

    const subscriptions =
      (
        subJson as {
          data?: {
            status: string;
            items?: { data?: { price?: { id?: string } }[] };
            current_period_end?: number;
          }[];
        }
      ).data ?? [];

    const sub = subscriptions[0];
    if (!sub) {
      return ok({
        active: false,
        status: null,
        customerId: customer.id,
        priceId: null,
        currentPeriodEnd: null,
      });
    }

    const active = sub.status === "active" || sub.status === "trialing";
    const priceId = sub.items?.data?.[0]?.price?.id ?? null;
    const currentPeriodEnd = sub.current_period_end
      ? new Date(sub.current_period_end * 1000).toISOString()
      : null;

    return ok({
      active,
      status: sub.status,
      customerId: customer.id,
      priceId,
      currentPeriodEnd,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Subscription status failed";
    return fail(message);
  }
}

function extractStripeError(json: unknown): string | undefined {
  if (
    typeof json === "object" &&
    json !== null &&
    "error" in json &&
    typeof (json as { error: unknown }).error === "object" &&
    (json as { error: { message?: unknown } }).error !== null
  ) {
    const message = (json as { error: { message?: unknown } }).error.message;
    return typeof message === "string" ? message : undefined;
  }
  return undefined;
}
