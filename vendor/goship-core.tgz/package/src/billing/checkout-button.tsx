"use client";

import { useState } from "react";
import { usePayment } from "../capabilities/payment";
import { isAuthConfigured } from "../auth/config";
import { useUser } from "../auth/use-user";
import { useAsyncAction } from "../hooks/use-async-action";

export interface CheckoutButtonProps {
  priceId?: string;
  checkoutPath?: string;
  label?: string;
  className?: string;
  onError?: (message: string) => void;
  /** Pre-checkout: abort if returns false */
  onBefore?: () => boolean | Promise<boolean>;
  /** Business metadata for webhook fulfillment */
  metadata?: Record<string, string>;
  mode?: "subscription" | "payment";
  /**
   * Product default: hide when payment unavailable (slot / null object UI).
   * Playground may set true to show a hint.
   */
  showWhenUnavailable?: boolean;
}

/**
 * Payment slot UI — usePayment + useAsyncAction lifecycle.
 * Unavailable → null. Do not call Stripe from apps.
 */
export function CheckoutButton({
  priceId,
  checkoutPath = "/api/billing/checkout",
  label = "Subscribe",
  className,
  onError,
  onBefore,
  metadata,
  mode,
  showWhenUnavailable = false,
}: CheckoutButtonProps) {
  const { isAvailable, pay } = usePayment();
  const { loading, configured: authConfigured } = useUser();
  const [message, setMessage] = useState<string | null>(null);

  const { execute: startCheckout, loading: pending } = useAsyncAction({
    eventName: "checkout",
    onBefore: async () => {
      setMessage(null);
      if (onBefore) {
        return onBefore();
      }
      return true;
    },
    action: async () => {
      const result = await pay({ priceId, checkoutPath, metadata, mode });
      if (!result.ok) {
        throw new Error(result.error ?? "Checkout failed");
      }
      return result;
    },
    onError: (error) => {
      const errMessage =
        error instanceof Error ? error.message : "Checkout failed";
      setMessage(errMessage);
      onError?.(errMessage);
    },
  });

  if (!isAvailable) {
    if (!showWhenUnavailable) return null;
    return (
      <div
        className={
          className ??
          "rounded-lg border border-border/50 bg-muted/40 px-4 py-3 text-sm text-muted-foreground"
        }
      >
        Payment unavailable — enable Stripe plugin + keys in Hub.
      </div>
    );
  }

  if (isAuthConfigured() && authConfigured && loading) {
    return (
      <div
        className={className ?? "h-9 w-28 animate-pulse rounded-lg bg-muted"}
        aria-hidden
      />
    );
  }

  return (
    <div className={className ?? "flex flex-col gap-2"}>
      <button
        type="button"
        disabled={pending}
        onClick={() => void startCheckout()}
        className="inline-flex h-9 items-center justify-center rounded-lg bg-primary px-4 text-sm text-primary-foreground transition-all duration-200 hover:scale-[1.01] disabled:opacity-60"
      >
        {pending ? "Redirecting…" : label}
      </button>
      {message ? (
        <p className="text-xs text-muted-foreground">{message}</p>
      ) : null}
    </div>
  );
}
