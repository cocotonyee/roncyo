"use client";

import { useCallback, useMemo, useState } from "react";
import { useUser } from "../auth/use-user";
import {
  getDefaultPriceId,
  getStripePublishableKey,
} from "../billing/config-client";
import { getEnv } from "../env";
import { isCapabilityActive } from "./active";

export interface PayOptions {
  priceId?: string;
  checkoutPath?: string;
  customerEmail?: string;
  /** Pre-checkout business metadata → Stripe session → webhook fulfill */
  metadata?: Record<string, string>;
  mode?: "subscription" | "payment";
}

export interface PaymentCapability {
  isAvailable: boolean;
  pay: (options?: PayOptions) => Promise<{ ok: boolean; error?: string }>;
}

function isStripePluginOnClient(): boolean {
  const pluginsPublic = process.env.NEXT_PUBLIC_PLUGINS_ENABLED;
  if (!pluginsPublic) return true;
  return pluginsPublic
    .split(",")
    .map((s) => s.trim())
    .includes("stripe");
}

/**
 * Capability API — do not import Stripe in app business code.
 */
export function usePayment(): PaymentCapability {
  const publishable = getStripePublishableKey();
  const defaultPrice = getDefaultPriceId();
  const { user } = useUser();
  const [paying, setPaying] = useState(false);

  // Available when Stripe keys + plugin are on. Price comes from code (or optional Hub default).
  const isAvailable = Boolean(publishable) && isStripePluginOnClient();

  const pay = useCallback(
    async (options?: PayOptions) => {
      if (!isAvailable || paying) {
        return { ok: false, error: "Payment is not available" };
      }

      const priceId = options?.priceId ?? defaultPrice;
      if (!priceId) {
        return {
          ok: false,
          error: "Missing priceId — pass priceId from code or set NEXT_PUBLIC_STRIPE_PRICE_ID",
        };
      }

      setPaying(true);
      try {
        const response = await fetch(
          options?.checkoutPath ?? "/api/billing/checkout",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              priceId,
              customerEmail: options?.customerEmail ?? user?.email ?? undefined,
              metadata: options?.metadata,
              mode: options?.mode,
            }),
          },
        );
        const json: unknown = await response.json();
        const result = json as {
          success?: boolean;
          data?: { url?: string };
          error?: string;
        };
        if (!response.ok || !result.success || !result.data?.url) {
          return {
            ok: false,
            error: result.error ?? `Checkout failed (${response.status})`,
          };
        }
        window.location.href = result.data.url;
        return { ok: true };
      } catch (error) {
        return {
          ok: false,
          error: error instanceof Error ? error.message : "Checkout failed",
        };
      } finally {
        setPaying(false);
      }
    },
    [isAvailable, paying, defaultPrice, user?.email],
  );

  return useMemo(() => ({ isAvailable, pay }), [isAvailable, pay]);
}

export function isPaymentAvailable(): boolean {
  const envReady = Boolean(
    getEnv("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY") && getEnv("STRIPE_SECRET_KEY"),
  );
  return isCapabilityActive("stripe", envReady);
}
