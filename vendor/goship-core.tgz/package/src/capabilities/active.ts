import { getEnv } from "../env";
import { isPluginEnabled } from "../plugins/enabled";

/**
 * Capability is ON when:
 * - PLUGINS_ENABLED lists the id AND envReady, OR
 * - PLUGINS_ENABLED is unset (legacy) and envReady
 */
export function isCapabilityActive(pluginId: string, envReady: boolean): boolean {
  if (!envReady) return false;
  const raw =
    getEnv("NEXT_PUBLIC_PLUGINS_ENABLED") ?? getEnv("PLUGINS_ENABLED");
  if (!raw) return true;
  return isPluginEnabled(pluginId);
}
