import { getEnv } from "../env";
import { isCapabilityActive } from "./active";
import type { TelemetryEventName, TrackEventPayload } from "../telemetry/types";

export interface TelemetryProvider {
  readonly isAvailable: boolean;
  trackEvent(name: TelemetryEventName, payload?: TrackEventPayload): void;
}

class NoopTelemetry implements TelemetryProvider {
  readonly isAvailable = false;
  trackEvent(): void {}
}

class ActiveTelemetry implements TelemetryProvider {
  readonly isAvailable = true;

  trackEvent(name: TelemetryEventName, payload?: TrackEventPayload): void {
    void this.dispatch(name, payload ?? {});
  }

  private async dispatch(
    name: string,
    payload: TrackEventPayload,
  ): Promise<void> {
    const key = getEnv("GOSHIP_TELEMETRY_KEY");
    if (!key) return;

    const directUrl = getEnv("GOSHIP_TELEMETRY_URL");
    const legacyHub = getEnv("HUB_API_GATEWAY_URL");
    const endpoint = directUrl
      ? directUrl
      : legacyHub
        ? `${legacyHub.replace(/\/$/, "")}/api/telemetry`
        : undefined;
    if (!endpoint) return;

    try {
      await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
          "X-Goship-Telemetry-Key": key,
        },
        body: JSON.stringify({
          name,
          payload,
          sentAt: new Date().toISOString(),
        }),
        keepalive: true,
      });
    } catch {
      // swallow
    }
  }
}

/** Resolve provider per call so env/plugin toggles apply without restart extremes */
export function getTelemetry(): TelemetryProvider {
  const envReady = Boolean(
    getEnv("GOSHIP_TELEMETRY_KEY") &&
      (getEnv("GOSHIP_TELEMETRY_URL") || getEnv("HUB_API_GATEWAY_URL")),
  );
  if (!isCapabilityActive("telemetry", envReady)) {
    return new NoopTelemetry();
  }
  return new ActiveTelemetry();
}

export const telemetry: TelemetryProvider = {
  get isAvailable() {
    return getTelemetry().isAvailable;
  },
  trackEvent(name, payload) {
    getTelemetry().trackEvent(name, payload);
  },
};
