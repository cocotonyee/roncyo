export { isAuthConfigured, isAuthEnabled, getAuthEntryMode, getAuthMethods, getSupabasePublicConfig } from "./config";
export type { AuthEntryMode, AuthMethods } from "./config";
export { createAuthBrowserClient } from "./browser";
export { useUser } from "./use-user";
export type { UseUserState } from "./use-user";
export { useAuth } from "./use-auth";
export type { UseAuthResult, AuthActionResult } from "./use-auth";
export { AuthButton } from "./auth-button";
export type { AuthButtonProps } from "./auth-button";
export { AuthPanel } from "./auth-panel";
export type { AuthPanelProps } from "./auth-panel";
export { LoginForm } from "./login-form";
export type { LoginFormProps } from "./login-form";
export { AuthModal } from "./auth-modal";
export type { AuthModalProps } from "./auth-modal";

/** Server-only helpers: import from `@goship/core/auth/server` */
