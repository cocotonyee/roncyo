import { createServerClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import { getSupabasePublicConfig, isAuthConfigured } from "./config";

/**
 * Server Supabase client for Next.js App Router.
 * Returns null when Auth env is missing (silent degrade).
 */
export async function createAuthServerClient(): Promise<SupabaseClient | null> {
  if (!isAuthConfigured()) {
    return null;
  }

  const config = getSupabasePublicConfig();
  if (!config) {
    return null;
  }

  const cookieStore = await cookies();

  return createServerClient(config.url, config.anonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(
        cookiesToSet: {
          name: string;
          value: string;
          options?: Record<string, unknown>;
        }[],
      ) {
        try {
          for (const { name, value, options } of cookiesToSet) {
            cookieStore.set(name, value, options);
          }
        } catch {
          // Called from a Server Component — middleware can refresh sessions.
        }
      },
    },
  });
}

