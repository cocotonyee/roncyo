"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import { getSupabasePublicConfig, isAuthConfigured } from "./config";

let browserClient: SupabaseClient | null = null;

/**
 * Browser Supabase client. Returns null when Auth env is missing (silent degrade).
 */
export function createAuthBrowserClient(): SupabaseClient | null {
  if (!isAuthConfigured()) {
    return null;
  }

  if (browserClient) {
    return browserClient;
  }

  const config = getSupabasePublicConfig();
  if (!config) {
    return null;
  }

  browserClient = createBrowserClient(config.url, config.anonKey);
  return browserClient;
}
