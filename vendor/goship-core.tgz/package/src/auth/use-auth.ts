"use client";

import { useCallback } from "react";
import { createAuthBrowserClient } from "./browser";
import {
  getAuthMethods,
  isAuthConfigured,
  isAuthEnabled,
  type AuthMethods,
} from "./config";
import { useUser, type UseUserState } from "./use-user";

export interface AuthActionResult {
  ok: boolean;
  error?: string;
}

export interface UseAuthResult extends UseUserState {
  isEnabled: boolean;
  methods: AuthMethods;
  /** Magic link email (Supabase OTP with redirect) */
  loginWithEmail: (
    email: string,
    options?: { redirectTo?: string },
  ) => Promise<AuthActionResult>;
  /** Send 6-digit email verification code */
  sendEmailOtp: (email: string) => Promise<AuthActionResult>;
  /** Verify email OTP code */
  verifyEmailOtp: (
    email: string,
    token: string,
  ) => Promise<AuthActionResult>;
  loginWithGoogle: (options?: {
    redirectTo?: string;
  }) => Promise<AuthActionResult>;
  loginWithApple: (options?: {
    redirectTo?: string;
  }) => Promise<AuthActionResult>;
}

function buildEmailRedirect(redirectTo: string): string | undefined {
  if (typeof window === "undefined") return undefined;
  return `${window.location.origin}/auth/callback?next=${encodeURIComponent(redirectTo)}`;
}

function missingKeysResult(): AuthActionResult {
  return {
    ok: false,
    error: "Auth is on, but Supabase keys are missing. Add them in Hub → Auth.",
  };
}

/**
 * Capability Auth API — apps must use this (or AuthButton / AuthPanel).
 */
export function useAuth(): UseAuthResult {
  const userState = useUser();
  const isEnabled = isAuthEnabled();
  const methods = getAuthMethods();

  const loginWithEmail = useCallback(
    async (
      email: string,
      options?: { redirectTo?: string },
    ): Promise<AuthActionResult> => {
      const client = createAuthBrowserClient();
      if (!client) return missingKeysResult();

      const next = options?.redirectTo ?? "/dashboard";
      const { error } = await client.auth.signInWithOtp({
        email: email.trim(),
        options: {
          emailRedirectTo: buildEmailRedirect(next),
          shouldCreateUser: true,
        },
      });

      if (error) return { ok: false, error: error.message };
      return { ok: true };
    },
    [],
  );

  const sendEmailOtp = useCallback(
    async (email: string): Promise<AuthActionResult> => {
      const client = createAuthBrowserClient();
      if (!client) return missingKeysResult();

      // Same OTP API; user verifies with code via verifyEmailOtp.
      // Configure Supabase Email template for OTP digits when using this path.
      const { error } = await client.auth.signInWithOtp({
        email: email.trim(),
        options: {
          shouldCreateUser: true,
        },
      });

      if (error) return { ok: false, error: error.message };
      return { ok: true };
    },
    [],
  );

  const verifyEmailOtp = useCallback(
    async (email: string, token: string): Promise<AuthActionResult> => {
      const client = createAuthBrowserClient();
      if (!client) return missingKeysResult();

      const { error } = await client.auth.verifyOtp({
        email: email.trim(),
        token: token.trim(),
        type: "email",
      });

      if (error) return { ok: false, error: error.message };
      return { ok: true };
    },
    [],
  );

  const loginWithOAuth = useCallback(
    async (
      provider: "google" | "apple",
      options?: { redirectTo?: string },
    ): Promise<AuthActionResult> => {
      const client = createAuthBrowserClient();
      if (!client) return missingKeysResult();

      const next = options?.redirectTo ?? "/dashboard";
      const { error } = await client.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: buildEmailRedirect(next),
        },
      });

      if (error) return { ok: false, error: error.message };
      return { ok: true };
    },
    [],
  );

  const loginWithGoogle = useCallback(
    (options?: { redirectTo?: string }) => loginWithOAuth("google", options),
    [loginWithOAuth],
  );

  const loginWithApple = useCallback(
    (options?: { redirectTo?: string }) => loginWithOAuth("apple", options),
    [loginWithOAuth],
  );

  return {
    ...userState,
    isEnabled,
    configured: isAuthConfigured(),
    methods,
    loginWithEmail,
    sendEmailOtp,
    verifyEmailOtp,
    loginWithGoogle,
    loginWithApple,
  };
}
