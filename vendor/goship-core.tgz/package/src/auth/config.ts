import { getEnv, hasEnv } from "../env";

export type AuthEntryMode = "modal" | "link";

export interface AuthMethods {
  google: boolean;
  apple: boolean;
  magicLink: boolean;
  emailOtp: boolean;
}

function readFlag(key: string, defaultOn: boolean): boolean {
  // Prefer getEnv — static NEXT_PUBLIC_* map (dynamic process.env[key] breaks CSR).
  const raw = (getEnv(key) ?? "").trim().toLowerCase();
  if (!raw) return defaultOn;
  if (["0", "false", "off", "no"].includes(raw)) return false;
  if (["1", "true", "on", "yes"].includes(raw)) return true;
  return defaultOn;
}

export function isAuthConfigured(): boolean {
  return hasEnv(
    "NEXT_PUBLIC_SUPABASE_URL",
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  );
}

/**
 * Auth is **built-in infrastructure** (default ON in new Hub projects),
 * but sites that don't need login can turn it off via Hub → Auth switch
 * (`auth` removed from `PLUGINS_ENABLED` / `NEXT_PUBLIC_PLUGINS_ENABLED`).
 *
 * Missing keys → UI still visible when ON; submit soft-fails via isAuthConfigured().
 */
export function isAuthEnabled(): boolean {
  const raw =
    getEnv("NEXT_PUBLIC_PLUGINS_ENABLED") ?? getEnv("PLUGINS_ENABLED");
  if (!raw) return true;
  return raw
    .split(",")
    .map((part) => part.trim().toLowerCase())
    .filter(Boolean)
    .includes("auth");
}

/**
 * Hub → `.env.local` `NEXT_PUBLIC_AUTH_ENTRY_MODE`.
 */
export function getAuthEntryMode(): AuthEntryMode {
  const raw = (getEnv("NEXT_PUBLIC_AUTH_ENTRY_MODE") ?? "modal")
    .trim()
    .toLowerCase();
  return raw === "link" ? "link" : "modal";
}

/**
 * Which login surfaces AuthPanel shows.
 * Defaults: Google + Magic Link on; Apple + Email OTP off.
 * Configure in Hub → Auth（写入 NEXT_PUBLIC_AUTH_*）.
 */
export function getAuthMethods(): AuthMethods {
  const methods: AuthMethods = {
    google: readFlag("NEXT_PUBLIC_AUTH_GOOGLE", true),
    apple: readFlag("NEXT_PUBLIC_AUTH_APPLE", false),
    magicLink: readFlag("NEXT_PUBLIC_AUTH_MAGIC_LINK", true),
    emailOtp: readFlag("NEXT_PUBLIC_AUTH_EMAIL_OTP", false),
  };

  // At least one email path if both email options off but OAuth also off
  if (
    !methods.google &&
    !methods.apple &&
    !methods.magicLink &&
    !methods.emailOtp
  ) {
    methods.magicLink = true;
  }

  return methods;
}

export function getSupabasePublicConfig():
  | { url: string; anonKey: string }
  | null {
  const url = getEnv("NEXT_PUBLIC_SUPABASE_URL");
  const anonKey = getEnv("NEXT_PUBLIC_SUPABASE_ANON_KEY");
  if (!url || !anonKey) {
    return null;
  }
  return { url, anonKey };
}
