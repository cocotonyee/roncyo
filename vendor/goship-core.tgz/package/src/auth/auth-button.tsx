"use client";

import { useState } from "react";
import Link from "next/link";
import { isAuthConfigured, isAuthEnabled, getAuthEntryMode } from "./config";
import { useUser } from "./use-user";
import { AuthModal } from "./auth-modal";

export interface AuthButtonProps {
  /**
   * Override Hub config. Default: `getAuthEntryMode()` from
   * `NEXT_PUBLIC_AUTH_ENTRY_MODE` (modal | link).
   */
  mode?: "modal" | "link";
  loginHref?: string;
  redirectTo?: string;
  className?: string;
  /** When Auth plugin off: hide (default) */
  hideWhenDisabled?: boolean;
}

/**
 * Product Auth control for navbars.
 * Entry mode comes from Hub env unless `mode` is passed.
 */
export function AuthButton({
  mode: modeProp,
  loginHref = "/login",
  redirectTo = "/dashboard",
  className,
  hideWhenDisabled = true,
}: AuthButtonProps) {
  const mode = modeProp ?? getAuthEntryMode();
  const enabled = isAuthEnabled();
  const configured = isAuthConfigured();
  const { user, loading, signOut } = useUser();
  const [open, setOpen] = useState(false);

  if (!enabled) {
    return hideWhenDisabled ? null : null;
  }

  if (configured && loading) {
    return (
      <div
        className={className ?? "h-9 w-20 animate-pulse rounded-lg bg-muted"}
        aria-hidden
      />
    );
  }

  if (user) {
    return (
      <div className={className ?? "flex items-center gap-3"}>
        <Link
          href="/dashboard"
          className="max-w-[160px] truncate text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          {user.email}
        </Link>
        <button
          type="button"
          onClick={() => void signOut()}
          className="inline-flex h-9 items-center rounded-lg border border-border/50 px-3 text-sm transition-all duration-200 hover:border-primary/50 hover:scale-[1.01]"
        >
          Sign out
        </button>
      </div>
    );
  }

  if (mode === "link") {
    return (
      <Link
        href={loginHref}
        className={
          className ??
          "inline-flex h-9 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground transition-all duration-200 hover:scale-[1.01]"
        }
      >
        Sign in
      </Link>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={
          className ??
          "inline-flex h-9 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground transition-all duration-200 hover:scale-[1.01]"
        }
      >
        Sign in
      </button>
      <AuthModal open={open} onOpenChange={setOpen} redirectTo={redirectTo} />
    </>
  );
}
