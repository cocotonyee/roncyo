import type { User } from "@supabase/supabase-js";
import { fail, ok, skipped, type PluginResult } from "../env";
import { createAuthServerClient } from "./server";

export type AuthUser = Pick<User, "id" | "email" | "created_at"> & {
  user_metadata: User["user_metadata"];
};

export async function getCurrentUser(): Promise<PluginResult<AuthUser | null>> {
  const client = await createAuthServerClient();
  if (!client) {
    return skipped("Auth not configured (missing Supabase env)");
  }

  try {
    const { data, error } = await client.auth.getUser();
    if (error) {
      return fail(error.message);
    }
    if (!data.user) {
      return ok(null);
    }
    return ok({
      id: data.user.id,
      email: data.user.email,
      created_at: data.user.created_at,
      user_metadata: data.user.user_metadata,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown auth error";
    return fail(message);
  }
}
