"use client";

import { useEffect, useId, useState } from "react";
import { createPortal } from "react-dom";
import { AuthPanel } from "./auth-panel";

export interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  description?: string;
  redirectTo?: string;
  showGoogle?: boolean;
}

function resolveLandingThemeClass(): string {
  if (typeof document === "undefined") return "landing-theme-zinc";
  const shell = document.querySelector(".landing-shell");
  if (shell) {
    for (const cls of shell.classList) {
      if (cls.startsWith("landing-theme-")) return cls;
    }
  }
  const id =
    document
      .querySelector("[data-landing-theme]")
      ?.getAttribute("data-landing-theme") ?? "zinc";
  return `landing-theme-${id}`;
}

/**
 * Auth dialog — portals to body but re-applies `.landing-shell` theme so
 * colors match the site (not the default light shadcn root).
 */
export function AuthModal({
  open,
  onOpenChange,
  title = "Welcome back",
  description = "Sign in with Google, Apple, magic link, or a verification code.",
  redirectTo,
  showGoogle,
}: AuthModalProps) {
  const titleId = useId();
  const descriptionId = useId();
  const [themeClass, setThemeClass] = useState("landing-theme-zinc");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!open) return;
    setThemeClass(resolveLandingThemeClass());

    const previousOverflow = document.body.style.overflow;
    const previousPaddingRight = document.body.style.paddingRight;
    const scrollbarGap =
      window.innerWidth - document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    if (scrollbarGap > 0) {
      document.body.style.paddingRight = `${scrollbarGap}px`;
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") onOpenChange(false);
    }

    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.body.style.paddingRight = previousPaddingRight;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [open, onOpenChange]);

  if (!open || !mounted) return null;

  return createPortal(
    <div
      className={`landing-shell ${themeClass} fixed inset-0 z-[200] flex items-center justify-center p-4`}
      data-landing-theme={themeClass.replace("landing-theme-", "")}
      role="presentation"
    >
      <button
        type="button"
        aria-label="Close dialog"
        className="absolute inset-0 bg-black/70 backdrop-blur-[2px] transition-opacity"
        onClick={() => onOpenChange(false)}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        className="landing-card relative z-10 w-full max-w-[400px] rounded-xl p-6 text-[var(--landing-fg)] shadow-2xl shadow-black/50"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 space-y-1 text-center">
          <h2
            id={titleId}
            className="text-xl font-semibold tracking-tight text-[var(--landing-fg)]"
          >
            {title}
          </h2>
          <p id={descriptionId} className="text-sm landing-muted">
            {description}
          </p>
        </div>
        <AuthPanel redirectTo={redirectTo} showGoogle={showGoogle} />
        <button
          type="button"
          onClick={() => onOpenChange(false)}
          className="mt-4 w-full text-center text-sm landing-muted transition-colors hover:text-[var(--landing-fg)]"
        >
          Cancel
        </button>
      </div>
    </div>,
    document.body,
  );
}
