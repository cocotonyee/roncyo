"use client";

import { useCallback, useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { createAuthBrowserClient } from "./browser";
import { isAuthConfigured } from "./config";

export interface UseUserState {
  user: User | null;
  loading: boolean;
  configured: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
}

/**
 * Client hook for current user. Degrades gracefully when Auth is not configured.
 */
export function useUser(): UseUserState {
  const configured = isAuthConfigured();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(configured);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const client = createAuthBrowserClient();
    if (!client) {
      setUser(null);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    try {
      const { data, error: sessionError } = await client.auth.getUser();
      if (sessionError) {
        setError(sessionError.message);
        setUser(null);
      } else {
        setError(null);
        setUser(data.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load user");
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    const client = createAuthBrowserClient();
    if (!client) return;
    await client.auth.signOut();
    setUser(null);
  }, []);

  useEffect(() => {
    void refresh();

    const client = createAuthBrowserClient();
    if (!client) return;

    const {
      data: { subscription },
    } = client.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [refresh]);

  return { user, loading, configured, error, refresh, signOut };
}
