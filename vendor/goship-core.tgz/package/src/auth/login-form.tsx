"use client";

import { AuthPanel } from "./auth-panel";

export interface LoginFormProps {
  onMagicLinkSent?: (email: string) => void;
  redirectTo?: string;
  className?: string;
  /** @deprecated Prefer AuthPanel; kept for email-only embeds */
  submitLabel?: string;
  showGoogle?: boolean;
}

/**
 * Login form surface — delegates to AuthPanel (useAuth).
 * Prefer AuthPanel / AuthModal for new UI.
 */
export function LoginForm({
  onMagicLinkSent,
  redirectTo,
  className,
  showGoogle = false,
}: LoginFormProps) {
  return (
    <AuthPanel
      redirectTo={redirectTo}
      showGoogle={showGoogle}
      className={className}
      onMagicLinkSent={onMagicLinkSent}
    />
  );
}
