"use client";

import { useMemo, useState, type FormEvent } from "react";
import { useAuth } from "./use-auth";
import { isAuthEnabled } from "./config";

function GoogleGlyph({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden>
      <path
        fill="currentColor"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="currentColor"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="currentColor"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="currentColor"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );
}

function AppleGlyph({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden fill="currentColor">
      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
    </svg>
  );
}

export interface AuthPanelProps {
  redirectTo?: string;
  className?: string;
  onMagicLinkSent?: (email: string) => void;
  /** @deprecated Prefer Hub NEXT_PUBLIC_AUTH_GOOGLE */
  showGoogle?: boolean;
}

type EmailMode = "magic" | "otp";

/**
 * Shared Auth UI — methods from Hub `getAuthMethods()`.
 */
export function AuthPanel({
  redirectTo = "/dashboard",
  className,
  onMagicLinkSent,
  showGoogle,
}: AuthPanelProps) {
  const {
    methods,
    loginWithEmail,
    sendEmailOtp,
    verifyEmailOtp,
    loginWithGoogle,
    loginWithApple,
  } = useAuth();
  const enabled = isAuthEnabled();

  const googleOn = showGoogle ?? methods.google;
  const appleOn = methods.apple;
  const magicOn = methods.magicLink;
  const otpOn = methods.emailOtp;
  const oauthOn = googleOn || appleOn;
  const emailOn = magicOn || otpOn;

  const defaultEmailMode: EmailMode = magicOn ? "magic" : "otp";
  const [emailMode, setEmailMode] = useState<EmailMode>(defaultEmailMode);
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [pending, setPending] = useState(false);
  const [oauthPending, setOauthPending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const activeEmailMode = useMemo(() => {
    if (emailMode === "magic" && magicOn) return "magic";
    if (emailMode === "otp" && otpOn) return "otp";
    return defaultEmailMode;
  }, [emailMode, magicOn, otpOn, defaultEmailMode]);

  if (!enabled) {
    return (
      <p className="text-sm landing-muted">
        Auth is unavailable. Check Hub → Auth keys.
      </p>
    );
  }

  async function handleGoogle() {
    setError(null);
    setMessage(null);
    setOauthPending(true);
    const result = await loginWithGoogle({ redirectTo });
    setOauthPending(false);
    if (!result.ok) setError(result.error ?? "Google sign-in failed");
  }

  async function handleApple() {
    setError(null);
    setMessage(null);
    setOauthPending(true);
    const result = await loginWithApple({ redirectTo });
    setOauthPending(false);
    if (!result.ok) setError(result.error ?? "Apple sign-in failed");
  }

  async function handleMagic(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setPending(true);
    const result = await loginWithEmail(email, { redirectTo });
    setPending(false);
    if (!result.ok) {
      setError(result.error ?? "Could not send magic link");
      return;
    }
    setMessage("Check your email for the magic link.");
    onMagicLinkSent?.(email.trim());
  }

  async function handleSendOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setPending(true);
    const result = await sendEmailOtp(email);
    setPending(false);
    if (!result.ok) {
      setError(result.error ?? "Could not send code");
      return;
    }
    setOtpSent(true);
    setMessage("Enter the verification code from your email.");
  }

  async function handleVerifyOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setPending(true);
    const result = await verifyEmailOtp(email, otp);
    setPending(false);
    if (!result.ok) {
      setError(result.error ?? "Invalid code");
      return;
    }
    setMessage("Signed in — redirecting…");
    window.location.assign(redirectTo);
  }

  const busy = pending || oauthPending;

  return (
    <div className={className ?? "space-y-4 text-[var(--landing-fg)]"}>
      {oauthOn ? (
        <div className="space-y-2">
          {googleOn ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleGoogle()}
              className="landing-cta-ghost inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-all duration-200 hover:scale-[1.01] disabled:opacity-60"
            >
              <GoogleGlyph className="h-4 w-4" />
              {oauthPending ? "Redirecting…" : "Continue with Google"}
            </button>
          ) : null}
          {appleOn ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleApple()}
              className="landing-cta-ghost inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-all duration-200 hover:scale-[1.01] disabled:opacity-60"
            >
              <AppleGlyph className="h-4 w-4" />
              {oauthPending ? "Redirecting…" : "Continue with Apple"}
            </button>
          ) : null}
        </div>
      ) : null}

      {oauthOn && emailOn ? (
        <div className="relative py-1">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t border-[var(--landing-card-border)]" />
          </div>
          <div className="relative flex justify-center text-[11px] uppercase tracking-wide">
            <span className="landing-card px-2 landing-muted">or</span>
          </div>
        </div>
      ) : null}

      {emailOn ? (
        <div className="space-y-3">
          {magicOn && otpOn ? (
            <div className="flex rounded-lg border border-[var(--landing-card-border)] p-0.5">
              <button
                type="button"
                onClick={() => {
                  setEmailMode("magic");
                  setOtpSent(false);
                  setMessage(null);
                  setError(null);
                }}
                className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium transition-colors ${
                  activeEmailMode === "magic"
                    ? "bg-[var(--landing-accent-soft)] text-[var(--landing-fg)]"
                    : "landing-muted"
                }`}
              >
                Magic link
              </button>
              <button
                type="button"
                onClick={() => {
                  setEmailMode("otp");
                  setMessage(null);
                  setError(null);
                }}
                className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium transition-colors ${
                  activeEmailMode === "otp"
                    ? "bg-[var(--landing-accent-soft)] text-[var(--landing-fg)]"
                    : "landing-muted"
                }`}
              >
                Verification code
              </button>
            </div>
          ) : null}

          {activeEmailMode === "magic" ? (
            <form onSubmit={(e) => void handleMagic(e)} className="space-y-3">
              <EmailField email={email} setEmail={setEmail} />
              <button
                type="submit"
                disabled={busy}
                className="landing-cta inline-flex h-10 w-full items-center justify-center rounded-lg px-4 text-sm font-medium transition-all duration-200 hover:scale-[1.01] disabled:opacity-60"
              >
                {pending ? "Sending link…" : "Send magic link"}
              </button>
            </form>
          ) : (
            <form
              onSubmit={(e) =>
                void (otpSent ? handleVerifyOtp(e) : handleSendOtp(e))
              }
              className="space-y-3"
            >
              <EmailField email={email} setEmail={setEmail} />
              {otpSent ? (
                <div className="space-y-1.5">
                  <label
                    htmlFor="goship-auth-otp"
                    className="text-sm font-medium text-[var(--landing-fg)]"
                  >
                    Code
                  </label>
                  <input
                    id="goship-auth-otp"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    required
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="123456"
                    className="h-10 w-full rounded-lg border border-[var(--landing-card-border)] bg-[var(--landing-bg)] px-3 text-sm tracking-widest text-[var(--landing-fg)] outline-none placeholder:text-[var(--landing-muted)] focus:border-[var(--landing-accent)]"
                  />
                </div>
              ) : null}
              <button
                type="submit"
                disabled={busy}
                className="landing-cta inline-flex h-10 w-full items-center justify-center rounded-lg px-4 text-sm font-medium transition-all duration-200 hover:scale-[1.01] disabled:opacity-60"
              >
                {pending
                  ? otpSent
                    ? "Verifying…"
                    : "Sending code…"
                  : otpSent
                    ? "Verify code"
                    : "Send verification code"}
              </button>
              {otpSent ? (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setOtpSent(false);
                    setOtp("");
                    setMessage(null);
                  }}
                  className="w-full text-center text-xs landing-muted hover:text-[var(--landing-fg)]"
                >
                  Use a different email
                </button>
              ) : null}
            </form>
          )}
        </div>
      ) : null}

      {message ? (
        <p className="text-sm text-emerald-400">{message}</p>
      ) : null}
      {error ? <p className="text-sm text-red-400">{error}</p> : null}
    </div>
  );
}

function EmailField({
  email,
  setEmail,
}: {
  email: string;
  setEmail: (v: string) => void;
}) {
  return (
    <div className="space-y-1.5">
      <label
        htmlFor="goship-auth-email"
        className="text-sm font-medium text-[var(--landing-fg)]"
      >
        Email
      </label>
      <input
        id="goship-auth-email"
        type="email"
        required
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@company.com"
        className="h-10 w-full rounded-lg border border-[var(--landing-card-border)] bg-[var(--landing-bg)] px-3 text-sm text-[var(--landing-fg)] outline-none transition-all duration-200 placeholder:text-[var(--landing-muted)] focus:border-[var(--landing-accent)]"
      />
    </div>
  );
}
