export type TelemetryEventName =
  | "user.signup"
  | "payment.success"
  | "system.error"
  | (string & {});

export interface TrackEventPayload {
  [key: string]: unknown;
}
