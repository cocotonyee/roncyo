import { telemetry } from "../capabilities/telemetry";
import type { TelemetryEventName, TrackEventPayload } from "./types";

export type { TelemetryEventName, TrackEventPayload };

/**
 * Fire-and-forget thin heartbeat.
 * Delegates to TelemetryProvider (Active or Noop) — never throws.
 */
export function trackEvent(
  name: TelemetryEventName,
  payload?: TrackEventPayload,
): void {
  telemetry.trackEvent(name, payload);
}

export function isTelemetryConfigured(): boolean {
  return telemetry.isAvailable;
}
