export { getEnv, hasEnv, ok, fail, skipped } from "./env";
export type { PluginResult } from "./env";

export * from "./auth";
/** Server auth: import from `@goship/core/auth/server` */

export * from "./telemetry";
export * from "./seo";
export * from "./plugins";
export * from "./capabilities";
export {
  createCheckoutSession,
  getSubscriptionStatusByEmail,
  isBillingConfigured,
  getDefaultPriceId,
  CheckoutButton,
} from "./billing";
export type {
  CheckoutInput,
  CheckoutButtonProps,
  SubscriptionStatus,
} from "./billing";

export { useAsyncAction } from "./hooks";
export type { AsyncActionOptions, AsyncActionState } from "./hooks";
export {
  sendMail,
  isMailConfigured,
  getDefaultFromEmail,
  SendTestMailForm,
} from "./mail";
export type { SendMailInput, SendTestMailFormProps } from "./mail";

export {
  createDefaultLandingConfig,
  LANDING_THEMES,
} from "./landing";
export type {
  LandingPageConfig,
  LandingTheme,
  LandingHeaderConfig,
  LandingHeroConfig,
  LandingTrustConfig,
  LandingFeaturesConfig,
  LandingFeatureItem,
  LandingPricingConfig,
  LandingPricingPlan,
  LandingFaqItem,
  LandingFooterConfig,
  LandingLink,
  LandingCta,
} from "./landing";
