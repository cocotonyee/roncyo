/**
 * Safe env helpers. Missing values never throw — callers degrade silently.
 *
 * Next.js only inlines `NEXT_PUBLIC_*` for **static** property access
 * (`process.env.NEXT_PUBLIC_FOO`). Dynamic `process.env[name]` is undefined
 * in the browser bundle and causes SSR/CSR mismatches (e.g. AuthButton hydration).
 */

/** Must list every public key read via getEnv / hasEnv. */
const PUBLIC_ENV: Record<string, string | undefined> = {
  NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  NEXT_PUBLIC_PLUGINS_ENABLED: process.env.NEXT_PUBLIC_PLUGINS_ENABLED,
  NEXT_PUBLIC_AUTH_ENTRY_MODE: process.env.NEXT_PUBLIC_AUTH_ENTRY_MODE,
  NEXT_PUBLIC_AUTH_GOOGLE: process.env.NEXT_PUBLIC_AUTH_GOOGLE,
  NEXT_PUBLIC_AUTH_APPLE: process.env.NEXT_PUBLIC_AUTH_APPLE,
  NEXT_PUBLIC_AUTH_MAGIC_LINK: process.env.NEXT_PUBLIC_AUTH_MAGIC_LINK,
  NEXT_PUBLIC_AUTH_EMAIL_OTP: process.env.NEXT_PUBLIC_AUTH_EMAIL_OTP,
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY:
    process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
  NEXT_PUBLIC_STRIPE_PRICE_ID: process.env.NEXT_PUBLIC_STRIPE_PRICE_ID,
  NEXT_PUBLIC_SITE_NAME: process.env.NEXT_PUBLIC_SITE_NAME,
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
  NEXT_PUBLIC_SITE_DESCRIPTION: process.env.NEXT_PUBLIC_SITE_DESCRIPTION,
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  NEXT_PUBLIC_APP_DESC: process.env.NEXT_PUBLIC_APP_DESC,
};

export function getEnv(name: string): string | undefined {
  const value = name.startsWith("NEXT_PUBLIC_")
    ? PUBLIC_ENV[name]
    : process.env[name];
  if (value === undefined || value.trim() === "") {
    return undefined;
  }
  return value.trim();
}

export function hasEnv(...names: string[]): boolean {
  return names.every((name) => Boolean(getEnv(name)));
}

export type PluginResult<T = void> =
  | { success: true; data: T }
  | { success: false; error: string; skipped?: boolean };

export function ok<T>(data: T): PluginResult<T> {
  return { success: true, data };
}

export function fail(error: string, skipped = false): PluginResult<never> {
  return { success: false, error, skipped };
}

export function skipped(reason: string): PluginResult<never> {
  return { success: false, error: reason, skipped: true };
}
