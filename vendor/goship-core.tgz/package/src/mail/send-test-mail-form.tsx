"use client";

import { useState, type FormEvent } from "react";

export interface SendTestMailFormProps {
  /** Defaults to /api/mail/send */
  sendPath?: string;
  className?: string;
  defaultTo?: string;
}

/**
 * Mail UI for playground: send a test email through the app API route.
 * Shows disabled state when the route reports skipped / not configured.
 */
export function SendTestMailForm({
  sendPath = "/api/mail/send",
  className,
  defaultTo = "",
}: SendTestMailFormProps) {
  const [to, setTo] = useState(defaultTo);
  const [subject, setSubject] = useState("GoShip test email");
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setMessage(null);

    try {
      const response = await fetch(sendPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to,
          subject,
          html: `<p>Hello from <strong>GoShip</strong> Mail plugin.</p><p>${new Date().toISOString()}</p>`,
        }),
      });

      const json: unknown = await response.json();
      const result = json as {
        success?: boolean;
        error?: string;
        skipped?: boolean;
        data?: { id?: string };
      };

      if (!result.success) {
        setMessage(
          result.skipped
            ? `Skipped: ${result.error ?? "Mail not configured"}`
            : result.error ?? "Send failed",
        );
        return;
      }

      setMessage(`Sent. id=${result.data?.id ?? "unknown"}`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Send failed");
    } finally {
      setPending(false);
    }
  }

  return (
    <form
      onSubmit={(e) => void onSubmit(e)}
      className={className ?? "flex flex-col gap-2"}
    >
      <input
        type="email"
        required
        value={to}
        onChange={(e) => setTo(e.target.value)}
        placeholder="to@example.com"
        className="h-9 rounded-lg border border-border/50 bg-background px-3 text-sm outline-none transition-all duration-200 focus:border-primary/50"
      />
      <input
        type="text"
        required
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        placeholder="Subject"
        className="h-9 rounded-lg border border-border/50 bg-background px-3 text-sm outline-none transition-all duration-200 focus:border-primary/50"
      />
      <button
        type="submit"
        disabled={pending}
        className="inline-flex h-9 items-center justify-center rounded-lg border border-border/50 px-3 text-sm transition-all duration-200 hover:border-primary/50 hover:scale-[1.01] disabled:opacity-60"
      >
        {pending ? "Sending…" : "Send test email"}
      </button>
      {message ? (
        <p className="text-xs text-muted-foreground">{message}</p>
      ) : null}
    </form>
  );
}
