export {
  sendMail,
  isMailConfigured,
  getDefaultFromEmail,
} from "./logic";
export type { SendMailInput } from "./logic";
export { SendTestMailForm } from "./send-test-mail-form";
export type { SendTestMailFormProps } from "./send-test-mail-form";
