import { getEnv, fail, ok, skipped, type PluginResult } from "../env";

export interface SendMailInput {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  from?: string;
  replyTo?: string;
}

export function isMailConfigured(): boolean {
  return Boolean(getEnv("RESEND_API_KEY"));
}

export function getDefaultFromEmail(): string | undefined {
  return getEnv("RESEND_FROM_EMAIL") ?? getEnv("MAIL_FROM");
}

/**
 * Send email via Resend. Missing RESEND_API_KEY → silent skip.
 */
export async function sendMail(
  input: SendMailInput,
): Promise<PluginResult<{ id: string }>> {
  const apiKey = getEnv("RESEND_API_KEY");
  if (!apiKey) {
    return skipped("RESEND_API_KEY not set");
  }

  const from = input.from ?? getDefaultFromEmail();
  if (!from) {
    return fail("Missing from address (RESEND_FROM_EMAIL or input.from)");
  }

  if (!input.to || !input.subject || !input.html) {
    return fail("to, subject, and html are required");
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: input.to,
        subject: input.subject,
        html: input.html,
        text: input.text,
        reply_to: input.replyTo,
      }),
    });

    const json: unknown = await response.json();

    if (!response.ok) {
      const message = extractResendError(json) ?? `Resend HTTP ${response.status}`;
      return fail(message);
    }

    const id = (json as { id?: string }).id;
    if (!id) {
      return fail("Resend response missing id");
    }

    return ok({ id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Mail send failed";
    return fail(message);
  }
}

function extractResendError(json: unknown): string | undefined {
  if (typeof json !== "object" || json === null) return undefined;
  if ("message" in json && typeof (json as { message: unknown }).message === "string") {
    return (json as { message: string }).message;
  }
  return undefined;
}
