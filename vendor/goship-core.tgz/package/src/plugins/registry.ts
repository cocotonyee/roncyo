/**
 * Site runtime plugin registry only (Auth / Billing / Mail / Telemetry).
 * Hub factory plugins (google-seo / deploy ledger) live in hub/legacy-ts — never here.
 * Blog is not a plugin; it reads seo_documents per contracts/seo-document.v1.json.
 */

export type PluginCategory =
  | "payment"
  | "auth"
  | "seo"
  | "telemetry"
  | "mail"
  | "deploy";

export type DualEnvMode = "test" | "live";

export interface PluginDualEnv {
  /** e.g. STRIPE_MODE — stores "test" | "live" */
  modeKey: string;
  modes: readonly DualEnvMode[];
  /** Canonical field keys that each get `__test` / `__live` bank copies */
  fieldKeys: string[];
}

export interface PluginConfigField {
  key: string;
  label: string;
  type: "text" | "password" | "boolean" | "select";
  placeholder?: string;
  required: boolean;
  /** For type: "select" */
  options?: { value: string; label: string }[];
}

export interface PluginDefinition {
  id: string;
  name: string;
  description: string;
  category: PluginCategory;
  fields: PluginConfigField[];
  /**
   * Built-in capability: default ON for new projects, always shown in Hub.
   * Still toggleable — some sites don't need login.
   */
  builtin?: boolean;
  /**
   * Hub stores test + live banks; child site only reads canonical field keys.
   */
  dualEnv?: PluginDualEnv;
}

export const PLUGIN_REGISTRY: PluginDefinition[] = [
  {
    id: "auth",
    name: "Supabase Auth",
    description: "默认基建 · 可关 · 开启时至少一种登录方式",
    category: "auth",
    builtin: true,
    fields: [
      {
        key: "NEXT_PUBLIC_AUTH_ENTRY_MODE",
        label: "登录入口",
        type: "select",
        required: false,
        placeholder: "modal",
        options: [
          { value: "modal", label: "弹窗（AuthModal）" },
          { value: "link", label: "独立页（/login）" },
        ],
      },
      {
        key: "NEXT_PUBLIC_AUTH_GOOGLE",
        label: "Google 登录",
        type: "boolean",
        required: false,
        placeholder: "1",
      },
      {
        key: "NEXT_PUBLIC_AUTH_APPLE",
        label: "Apple 登录",
        type: "boolean",
        required: false,
        placeholder: "0",
      },
      {
        key: "NEXT_PUBLIC_AUTH_MAGIC_LINK",
        label: "邮箱魔法链接",
        type: "boolean",
        required: false,
        placeholder: "1",
      },
      {
        key: "NEXT_PUBLIC_AUTH_EMAIL_OTP",
        label: "邮箱验证码",
        type: "boolean",
        required: false,
        placeholder: "0",
      },
      {
        key: "NEXT_PUBLIC_SUPABASE_URL",
        label: "Supabase URL",
        type: "text",
        placeholder: "https://xxx.supabase.co",
        required: true,
      },
      {
        key: "NEXT_PUBLIC_SUPABASE_ANON_KEY",
        label: "Supabase Anon Key",
        type: "password",
        placeholder: "eyJ...",
        required: true,
      },
      {
        key: "SUPABASE_SERVICE_ROLE_KEY",
        label: "Service Role Key (Hub Live Admin)",
        type: "password",
        placeholder: "eyJ... service_role",
        required: false,
      },
    ],
  },
  {
    id: "stripe",
    name: "Stripe 支付与订阅",
    description: "Checkout、订阅状态与 Webhook 履约（可选插件）",
    category: "payment",
    dualEnv: {
      modeKey: "STRIPE_MODE",
      modes: ["test", "live"],
      fieldKeys: [
        "STRIPE_SECRET_KEY",
        "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY",
        "NEXT_PUBLIC_STRIPE_PRICE_ID",
        "STRIPE_WEBHOOK_SECRET",
      ],
    },
    fields: [
      {
        key: "STRIPE_SECRET_KEY",
        label: "Stripe Secret Key",
        type: "password",
        placeholder: "sk_test_...",
        required: true,
      },
      {
        key: "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY",
        label: "Publishable Key",
        type: "text",
        placeholder: "pk_test_...",
        required: true,
      },
      {
        key: "NEXT_PUBLIC_STRIPE_PRICE_ID",
        label: "Default Price ID（可选）",
        type: "text",
        placeholder: "price_... · 业务代码也可传 priceId",
        required: false,
      },
      {
        key: "STRIPE_WEBHOOK_SECRET",
        label: "Webhook Secret",
        type: "password",
        placeholder: "whsec_...",
        required: false,
      },
    ],
  },
  {
    id: "mail",
    name: "Resend 邮件",
    description: "事务邮件发送（欢迎信、收据等）",
    category: "mail",
    fields: [
      {
        key: "RESEND_API_KEY",
        label: "Resend API Key",
        type: "password",
        placeholder: "re_...",
        required: true,
      },
      {
        key: "RESEND_FROM_EMAIL",
        label: "From Email",
        type: "text",
        placeholder: "onboarding@resend.dev",
        required: true,
      },
    ],
  },
];

export function getPluginDefinition(id: string): PluginDefinition | undefined {
  return PLUGIN_REGISTRY.find((plugin) => plugin.id === id);
}

export function listPluginIds(): string[] {
  return PLUGIN_REGISTRY.map((plugin) => plugin.id);
}

export function listBuiltinPluginIds(): string[] {
  return PLUGIN_REGISTRY.filter((p) => p.builtin).map((p) => p.id);
}

export function listToggleablePlugins(): PluginDefinition[] {
  return PLUGIN_REGISTRY.filter((p) => !p.builtin);
}

/** Bank key: STRIPE_SECRET_KEY__test */
export function dualEnvBankKey(canonical: string, mode: DualEnvMode): string {
  return `${canonical}__${mode}`;
}

/**
 * Allowed secret keys for Hub save-config:
 * registry field keys + dualEnv modeKey + bank suffixes.
 */
export function listAllowedSecretKeys(): string[] {
  const keys = new Set<string>();
  for (const plugin of PLUGIN_REGISTRY) {
    for (const field of plugin.fields) {
      keys.add(field.key);
    }
    const dual = plugin.dualEnv;
    if (!dual) continue;
    keys.add(dual.modeKey);
    for (const fieldKey of dual.fieldKeys) {
      for (const mode of dual.modes) {
        keys.add(dualEnvBankKey(fieldKey, mode));
      }
    }
  }
  return Array.from(keys);
}
