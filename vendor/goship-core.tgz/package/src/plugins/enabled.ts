import { getEnv } from "../env";

/**
 * Feature-flag reader for generated SaaS apps.
 * Hub writes both `PLUGINS_ENABLED` and `NEXT_PUBLIC_PLUGINS_ENABLED`.
 * Prefer the public key so Client Components can read the same list.
 */
function readPluginsEnabledRaw(): string | undefined {
  return getEnv("NEXT_PUBLIC_PLUGINS_ENABLED") ?? getEnv("PLUGINS_ENABLED");
}

export function isPluginEnabled(id: string): boolean {
  const raw = readPluginsEnabledRaw();
  if (!raw) {
    return false;
  }
  return raw
    .split(",")
    .map((part) => part.trim().toLowerCase())
    .filter(Boolean)
    .includes(id.toLowerCase());
}

export function listEnabledPluginIds(): string[] {
  const raw = readPluginsEnabledRaw();
  if (!raw) return [];
  return raw
    .split(",")
    .map((part) => part.trim().toLowerCase())
    .filter(Boolean);
}
