"use client";

import { useCallback, useRef, useState } from "react";
import { telemetry } from "../capabilities/telemetry";

export interface AsyncActionOptions<TParam, TResult> {
  /** Pre-action: return false to abort */
  onBefore?: (param: TParam) => boolean | Promise<boolean>;
  /** Core work (API / SDK) */
  action: (param: TParam) => Promise<TResult>;
  /** Post-action success (UI) */
  onSuccess?: (result: TResult, param: TParam) => void;
  /** Post-action error */
  onError?: (error: unknown, param: TParam) => void;
  /** Auto telemetry: `${eventName}_success` / `${eventName}_failed` */
  eventName?: string;
}

export interface AsyncActionState<TParam> {
  execute: (param: TParam) => Promise<void>;
  loading: boolean;
}

/**
 * Click lifecycle: Pre → Action → Post (success|error).
 * Apps/Cursor use this for custom buttons; do not reinvent loading/telemetry.
 */
export function useAsyncAction<TParam = void, TResult = unknown>(
  options: AsyncActionOptions<TParam, TResult>,
): AsyncActionState<TParam> {
  const [loading, setLoading] = useState(false);
  const optionsRef = useRef(options);
  optionsRef.current = options;

  const execute = useCallback(async (param: TParam) => {
    const opts = optionsRef.current;
    try {
      if (opts.onBefore) {
        const canProceed = await opts.onBefore(param);
        if (!canProceed) return;
      }

      setLoading(true);
      const result = await opts.action(param);

      if (opts.eventName) {
        telemetry.trackEvent(`${opts.eventName}_success`, {
          hasParam: param !== undefined && param !== null,
        });
      }

      opts.onSuccess?.(result, param);
    } catch (error) {
      if (opts.eventName) {
        telemetry.trackEvent(`${opts.eventName}_failed`, {
          message: error instanceof Error ? error.message : "unknown",
        });
      }
      opts.onError?.(error, param);
    } finally {
      setLoading(false);
    }
  }, []);

  return { execute, loading };
}
