import type { LandingPageConfig } from "./types";

/** Default puzzle used by starter / Hub seed. */
export function createDefaultLandingConfig(
  overrides?: Partial<{
    name: string;
    description: string;
  }>,
): LandingPageConfig {
  const name = overrides?.name?.trim() || "GoShip";
  const description =
    overrides?.description?.trim() ||
    "Ship a Micro-SaaS faster with Auth, Billing, Mail, and SEO built in.";

  return {
    theme: "zinc",
    header: {
      logoText: `${name}.`,
      links: [
        { label: "How It Works", href: "#features" },
        { label: "Pricing", href: "#pricing" },
        { label: "FAQ", href: "#faq" },
        { label: "Blog", href: "/blog" },
      ],
      secondaryLink: { label: "For Business", href: "/pricing" },
      primaryCta: { text: "Get started", href: "/login" },
      showAuthButton: true,
    },
    hero: {
      badgeText: "Indie SaaS starter",
      title: "Ship. Instantly.",
      highlightWord: "Instantly.",
      description,
      primaryCta: { text: "Get started", href: "/login" },
      secondaryCta: { text: "View pricing", href: "#pricing" },
      platforms: ["Web", "iOS", "Android"],
      trustMarkers: [
        { label: "< 4min setup" },
        { label: "Encrypted keys" },
        { label: "99.9% uptime" },
        { label: "4.8 ★" },
      ],
    },
    trust: {
      showLogos: true,
      title: "Trusted by builders shipping weekly",
      logos: [
        { name: "Acme" },
        { name: "Northwind" },
        { name: "Globex" },
        { name: "Initech" },
      ],
    },
    features: {
      title: "Shipping made simple.",
      highlightWord: "simple.",
      description: "Plugins stay optional — turn them on when keys are ready.",
      items: [
        {
          icon: "Smartphone",
          title: "Multiplatform",
          description:
            "One account everywhere — start on your phone, finish on your laptop.",
          tags: ["Web", "iOS", "Android", "macOS"],
        },
        {
          icon: "RefreshCw",
          title: "Auth & Billing",
          description:
            "Magic-link login and Stripe Checkout when you are ready to charge.",
          tags: ["Supabase", "Stripe", "Resend"],
        },
        {
          icon: "Search",
          title: "SEO ready",
          description:
            "SSR landing + blog, sitemap, robots, and llms.txt from day one.",
          tags: ["SSR", "JSON-LD", "GEO"],
        },
      ],
    },
    pricing: {
      title: "Simple pricing",
      description: "Start free. Upgrade when you close the first customer.",
      plans: [
        {
          name: "Starter",
          price: "$0",
          description: "Validate the idea",
          cta: { text: "Start free", href: "/login" },
          features: ["Auth + blog", "Local telemetry", "Hub factory sync"],
        },
        {
          name: "Pro",
          price: "$29",
          description: "When you are ready to charge",
          featured: true,
          cta: { text: "Upgrade", href: "/pricing" },
          features: [
            "Stripe subscriptions",
            "Priority support",
            "AI SEO seeds (Hub)",
          ],
        },
      ],
    },
    faq: [
      {
        question: "Do I need Hub in production?",
        answer:
          "No. Hub is localhost-only. The shipped site only needs its own env and landing.json.",
      },
      {
        question: "Can I edit copy without touching React?",
        answer:
          "Yes. Edit landing.json in Hub’s Landing tab — the page re-renders as pure HTML.",
      },
      {
        question: "What if a plugin has no keys?",
        answer:
          "UI can still show when the Hub toggle is on; runtime calls degrade silently.",
      },
    ],
    footer: {
      tagline: "Ship Micro-SaaS faster — no machine-room needed.",
      trustBadges: ["TLS-encrypted secrets", "Localhost Hub only"],
      copyright: `© ${new Date().getFullYear()} ${name} · by GoShip`,
      columns: [
        {
          links: [
            { label: "Features", href: "#features" },
            { label: "Pricing", href: "#pricing" },
            { label: "Blog", href: "/blog" },
            { label: "Support", href: "#" },
          ],
        },
        {
          links: [
            { label: "Docs", href: "#" },
            { label: "API", href: "#" },
            { label: "Company", href: "#" },
          ],
        },
      ],
      links: [
        { label: "Blog", href: "/blog" },
        { label: "Pricing", href: "/pricing" },
      ],
      storeLinks: [
        { label: "Web App", href: "/login" },
        { label: "App Store", href: "#" },
        { label: "Google Play", href: "#" },
      ],
      legalLinks: [
        { label: "Terms", href: "#" },
        { label: "Privacy", href: "#" },
        { label: "Refund", href: "#" },
      ],
    },
  };
}
