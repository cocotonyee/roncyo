export type {
  LandingPageConfig,
  LandingTheme,
  LandingHeaderConfig,
  LandingHeroConfig,
  LandingTrustMarker,
  LandingTrustConfig,
  LandingFeaturesConfig,
  LandingFeatureItem,
  LandingPricingConfig,
  LandingPricingPlan,
  LandingFaqItem,
  LandingFooterColumn,
  LandingFooterConfig,
  LandingLink,
  LandingCta,
} from "./types";
export { LANDING_THEMES } from "./types";
export { createDefaultLandingConfig } from "./default";
