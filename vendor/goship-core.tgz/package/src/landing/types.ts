/**
 * Schema-driven landing page — Hub edits → child `src/config/landing.json`.
 */

/** Accent skin id — dark charcoal shell + this accent. */
export type LandingTheme =
  | "zinc"
  | "violet"
  | "emerald"
  | "sunset"
  | "rose"
  | "cyan"
  | "amber"
  | "indigo";

export const LANDING_THEMES: Array<{
  id: LandingTheme;
  label: string;
  hint: string;
  /** Hub 小色块 */
  swatch: { accent: string };
}> = [
  { id: "zinc", label: "蓝", hint: "冷蓝", swatch: { accent: "#3b82f6" } },
  { id: "violet", label: "紫", hint: "科技紫", swatch: { accent: "#8b5cf6" } },
  { id: "indigo", label: "靛", hint: "靛蓝", swatch: { accent: "#6366f1" } },
  { id: "cyan", label: "青", hint: "青色", swatch: { accent: "#06b6d4" } },
  { id: "emerald", label: "绿", hint: "增长绿", swatch: { accent: "#10b981" } },
  { id: "amber", label: "琥珀", hint: "暖琥珀", swatch: { accent: "#f59e0b" } },
  { id: "sunset", label: "橙", hint: "暖橙", swatch: { accent: "#f97316" } },
  { id: "rose", label: "玫", hint: "玫红", swatch: { accent: "#f43f5e" } },
];

export interface LandingLink {
  label: string;
  href: string;
}

export interface LandingCta {
  text: string;
  href: string;
}

export interface LandingHeaderConfig {
  logoText: string;
  links: LandingLink[];
  showAuthButton: boolean;
  /** Optional right-side text link (e.g. For Business →) */
  secondaryLink?: LandingLink;
  /** Optional accent CTA in header (e.g. Fax Now) */
  primaryCta?: LandingCta;
}

export interface LandingTrustMarker {
  label: string;
}

export interface LandingHeroConfig {
  badgeText?: string;
  title: string;
  /** Word/phrase in title to accent + underline (e.g. "Instantly.") */
  highlightWord?: string;
  description: string;
  primaryCta: LandingCta;
  secondaryCta?: LandingCta;
  /** Row under CTA: "ALSO ON" style chips */
  platforms?: string[];
  /** Social proof under hero: "< 4min send", "256-bit encrypted" */
  trustMarkers?: LandingTrustMarker[];
}

export interface LandingTrustConfig {
  showLogos: boolean;
  title?: string;
  logos: Array<{ name: string; imageUrl?: string }>;
}

export interface LandingFeatureItem {
  title: string;
  description: string;
  tags?: string[];
  /** Lucide icon name (e.g. "Smartphone", "RefreshCw") */
  icon?: string;
}

export interface LandingFeaturesConfig {
  title: string;
  /** Accent word inside title (e.g. "simple.") */
  highlightWord?: string;
  description?: string;
  items: LandingFeatureItem[];
}

export interface LandingPricingPlan {
  name: string;
  price: string;
  description?: string;
  cta: LandingCta;
  featured?: boolean;
  features: string[];
}

export interface LandingPricingConfig {
  title: string;
  description?: string;
  plans: LandingPricingPlan[];
}

export interface LandingFaqItem {
  question: string;
  answer: string;
}

export interface LandingFooterColumn {
  title?: string;
  links: LandingLink[];
}

export interface LandingFooterConfig {
  copyright: string;
  /** Brand line under logo */
  tagline?: string;
  trustBadges?: string[];
  /** Multi-column nav; falls back to flat `links` */
  columns?: LandingFooterColumn[];
  links: LandingLink[];
  storeLinks?: LandingLink[];
  legalLinks?: LandingLink[];
}

export interface LandingPageConfig {
  /** Visual skin — maps to `.landing-theme-*` on the page shell */
  theme: LandingTheme;
  header: LandingHeaderConfig;
  hero: LandingHeroConfig;
  trust: LandingTrustConfig;
  features: LandingFeaturesConfig;
  pricing: LandingPricingConfig;
  faq: LandingFaqItem[];
  footer: LandingFooterConfig;
}
