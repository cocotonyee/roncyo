import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { getEnv } from "../env";
import { getSiteProfile } from "./profile";
import { getDemoSeoDocuments } from "./demo-documents";
import { rowToSeoDocument, type SeoDocumentRow } from "./row-map";
import type { SeoDocument } from "./types";

function createSeoSupabase(): SupabaseClient | null {
  const url = getEnv("NEXT_PUBLIC_SUPABASE_URL");
  // Prefer anon for public published reads; service role also works server-side.
  const key =
    getEnv("NEXT_PUBLIC_SUPABASE_ANON_KEY") ??
    getEnv("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return null;
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

async function fetchPublishedFromDb(
  siteId: string,
): Promise<SeoDocument[] | null> {
  const supabase = createSeoSupabase();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from("seo_documents")
      .select("*")
      .eq("site_id", siteId)
      .eq("status", "published")
      .order("published_at", { ascending: false, nullsFirst: false });

    if (error) {
      // Table missing / RLS / network — silent Null Object
      return null;
    }

    return (data as SeoDocumentRow[]).map(rowToSeoDocument);
  } catch {
    return null;
  }
}

/**
 * List published documents.
 * Prefer Supabase `seo_documents`; fall back to demo seed when profile exists
 * but DB is unavailable/empty of schema; return [] when no profile.
 */
export async function listPublishedDocuments(): Promise<SeoDocument[]> {
  const profile = getSiteProfile();
  if (!profile) {
    return [];
  }

  const fromDb = await fetchPublishedFromDb(profile.siteId);
  if (fromDb !== null) {
    return fromDb.filter((doc) => !doc.noindex);
  }

  return getDemoSeoDocuments(profile.siteId).filter(
    (doc) => doc.status === "published",
  );
}

export async function getDocumentBySlug(
  slug: string,
): Promise<SeoDocument | null> {
  const profile = getSiteProfile();
  if (!profile) return null;

  const supabase = createSeoSupabase();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from("seo_documents")
        .select("*")
        .eq("site_id", profile.siteId)
        .eq("slug", slug)
        .eq("status", "published")
        .maybeSingle();

      if (!error && data) {
        const doc = rowToSeoDocument(data as SeoDocumentRow);
        return doc.noindex ? null : doc;
      }
    } catch {
      // fall through
    }
  }

  const docs = await listPublishedDocuments();
  return docs.find((doc) => doc.slug === slug) ?? null;
}
