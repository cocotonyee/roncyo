import type { Metadata } from "next";
import type { SeoDocument, SiteProfile } from "./types";

export function resolveCanonicalUrl(
  profile: SiteProfile,
  doc: SeoDocument,
): string {
  if (doc.canonicalPath) {
    if (doc.canonicalPath.startsWith("http")) {
      return doc.canonicalPath;
    }
    return `${profile.domain}${doc.canonicalPath.startsWith("/") ? "" : "/"}${doc.canonicalPath}`;
  }
  return `${profile.domain}/blog/${doc.slug}`;
}

function resolveAbsoluteUrl(profile: SiteProfile, pathOrUrl: string): string {
  if (pathOrUrl.startsWith("http://") || pathOrUrl.startsWith("https://")) {
    return pathOrUrl;
  }
  const base = profile.domain.replace(/\/$/, "");
  return `${base}${pathOrUrl.startsWith("/") ? "" : "/"}${pathOrUrl}`;
}

export function buildMetadata(
  profile: SiteProfile,
  doc?: SeoDocument,
): Metadata {
  if (!doc) {
    return {
      title: {
        default: profile.name,
        template: profile.defaultTitleTemplate,
      },
      description: profile.defaultDescription,
      metadataBase: new URL(profile.domain),
    };
  }

  const canonical = resolveCanonicalUrl(profile, doc);
  const imageUrl = doc.image
    ? resolveAbsoluteUrl(profile, doc.image)
    : undefined;

  return {
    title: doc.title,
    description: doc.description,
    keywords: doc.keywords?.length ? doc.keywords : doc.tags,
    authors: doc.author?.name
      ? [{ name: doc.author.name, url: doc.author.url }]
      : [{ name: profile.organization.name, url: profile.organization.url }],
    category: doc.category,
    robots: doc.noindex
      ? { index: false, follow: false }
      : { index: true, follow: true },
    alternates: { canonical },
    openGraph: {
      title: doc.title,
      description: doc.description,
      url: canonical,
      type: "article",
      locale: doc.locale,
      siteName: profile.name,
      publishedTime: doc.publishedAt ?? doc.createdAt,
      modifiedTime: doc.updatedAt,
      authors: doc.author?.name
        ? [doc.author.name]
        : [profile.organization.name],
      section: doc.category,
      tags: doc.tags,
      ...(imageUrl
        ? {
            images: [
              {
                url: imageUrl,
                alt: doc.imageAlt ?? doc.title,
              },
            ],
          }
        : {}),
    },
    twitter: {
      card: imageUrl ? "summary_large_image" : "summary",
      title: doc.title,
      description: doc.description,
      ...(imageUrl ? { images: [imageUrl] } : {}),
    },
  };
}

export function buildJsonLd(
  profile: SiteProfile,
  doc: SeoDocument,
): Record<string, unknown>[] {
  const canonical = resolveCanonicalUrl(profile, doc);
  const imageUrl = doc.image
    ? resolveAbsoluteUrl(profile, doc.image)
    : undefined;

  const authorNode = doc.author?.name
    ? {
        "@type": "Person",
        name: doc.author.name,
        ...(doc.author.url ? { url: doc.author.url } : {}),
        ...(doc.author.image
          ? { image: resolveAbsoluteUrl(profile, doc.author.image) }
          : {}),
        ...(doc.author.role ? { jobTitle: doc.author.role } : {}),
      }
    : {
        "@type": "Organization",
        name: profile.organization.name,
        url: profile.organization.url,
      };

  const graph: Record<string, unknown>[] = [
    {
      "@type": "Organization",
      name: profile.organization.name,
      url: profile.organization.url,
      ...(profile.organization.logoUrl
        ? { logo: profile.organization.logoUrl }
        : {}),
      ...(profile.organization.sameAs?.length
        ? { sameAs: profile.organization.sameAs }
        : {}),
    },
    {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: profile.domain,
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Blog",
          item: `${profile.domain.replace(/\/$/, "")}/blog`,
        },
        {
          "@type": "ListItem",
          position: 3,
          name: doc.title,
          item: canonical,
        },
      ],
    },
    {
      "@type": "Article",
      headline: doc.title,
      description: doc.description,
      datePublished: doc.publishedAt ?? doc.createdAt,
      dateModified: doc.updatedAt,
      inLanguage: doc.locale,
      mainEntityOfPage: {
        "@type": "WebPage",
        "@id": canonical,
      },
      author: authorNode,
      publisher: {
        "@type": "Organization",
        name: profile.organization.name,
        url: profile.organization.url,
        ...(profile.organization.logoUrl
          ? {
              logo: {
                "@type": "ImageObject",
                url: profile.organization.logoUrl,
              },
            }
          : {}),
      },
      ...(imageUrl
        ? {
            image: {
              "@type": "ImageObject",
              url: imageUrl,
              ...(doc.imageAlt ? { caption: doc.imageAlt } : {}),
            },
          }
        : {}),
      ...(doc.wordCount ? { wordCount: doc.wordCount } : {}),
      ...(doc.keywords?.length || doc.tags?.length
        ? { keywords: (doc.keywords ?? doc.tags)?.join(", ") }
        : {}),
      ...(doc.category ? { articleSection: doc.category } : {}),
      ...(doc.quickAnswer
        ? {
            abstract: doc.quickAnswer,
          }
        : {}),
    },
  ];

  if (doc.faq.length > 0) {
    graph.push({
      "@type": "FAQPage",
      mainEntity: doc.faq.map((item) => ({
        "@type": "Question",
        name: item.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: item.answer,
        },
      })),
    });
  }

  return graph;
}

export function buildJsonLdScript(
  profile: SiteProfile,
  doc: SeoDocument,
): string {
  return JSON.stringify({
    "@context": "https://schema.org",
    "@graph": buildJsonLd(profile, doc),
  });
}

export interface SitemapEntry {
  url: string;
  lastModified?: string;
}

export function buildSitemapEntries(
  profile: SiteProfile,
  docs: SeoDocument[],
): SitemapEntry[] {
  const home: SitemapEntry = {
    url: profile.domain,
    lastModified: new Date().toISOString(),
  };

  const articles = docs
    .filter((doc) => doc.status === "published" && !doc.noindex)
    .map((doc) => ({
      url: resolveCanonicalUrl(profile, doc),
      lastModified: doc.updatedAt,
    }));

  return [home, ...articles];
}

export function buildRobots(profile: SiteProfile): {
  rules: { userAgent: string; allow: string };
  sitemap: string;
} {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: `${profile.domain}/sitemap.xml`,
  };
}

export function buildLlmsTxt(
  profile: SiteProfile,
  docs: SeoDocument[],
): string {
  const published = docs.filter(
    (doc) => doc.status === "published" && !doc.noindex,
  );
  const lines = [
    `# ${profile.name}`,
    "",
    `> ${profile.productBlurb}`,
    "",
    `Site: ${profile.domain}`,
    `Locale: ${profile.locale}`,
    "",
    "## Product",
    profile.productBlurb,
    "",
    "## Key pages",
    `- Home: ${profile.domain}/`,
    `- Blog: ${profile.domain.replace(/\/$/, "")}/blog`,
    ...published.map(
      (doc) => `- ${doc.title}: ${resolveCanonicalUrl(profile, doc)}`,
    ),
    "",
    "## Optional",
    `- Sitemap: ${profile.domain}/sitemap.xml`,
    `- RSS: ${profile.domain.replace(/\/$/, "")}/blog/rss.xml`,
  ];

  if (profile.contactEmail) {
    lines.push(`- Contact: ${profile.contactEmail}`);
  }

  return `${lines.join("\n")}\n`;
}
