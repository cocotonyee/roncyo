import { getEnv } from "../env";
import type { SiteProfile } from "./types";

/**
 * Reads SiteProfile from env. Returns null when required fields are missing
 * (silent degrade — never throws).
 */
export function getSiteProfile(): SiteProfile | null {
  const siteId = getEnv("GOSHIP_SITE_ID");
  const name = getEnv("GOSHIP_SITE_NAME") ?? getEnv("NEXT_PUBLIC_SITE_NAME");
  const domain = getEnv("GOSHIP_SITE_DOMAIN") ?? getEnv("NEXT_PUBLIC_SITE_URL");

  if (!siteId || !name || !domain) {
    return null;
  }

  const locale = getEnv("GOSHIP_SITE_LOCALE") ?? "en";
  const organizationName = getEnv("GOSHIP_ORG_NAME") ?? name;
  const productBlurb =
    getEnv("GOSHIP_PRODUCT_BLURB") ?? getEnv("NEXT_PUBLIC_SITE_DESCRIPTION") ?? "";

  return {
    siteId,
    name,
    domain: domain.replace(/\/$/, ""),
    locale,
    defaultTitleTemplate: getEnv("GOSHIP_TITLE_TEMPLATE") ?? `%s | ${name}`,
    defaultDescription:
      getEnv("GOSHIP_SITE_DESCRIPTION") ??
      getEnv("NEXT_PUBLIC_SITE_DESCRIPTION") ??
      "",
    organization: {
      name: organizationName,
      url: domain.replace(/\/$/, ""),
      logoUrl: getEnv("GOSHIP_ORG_LOGO_URL"),
    },
    productBlurb,
    contactEmail: getEnv("GOSHIP_CONTACT_EMAIL"),
  };
}

export type { SiteProfile, SeoDocument, SeoAction, SeoFaqItem, SeoEntity } from "./types";
