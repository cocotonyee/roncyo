import type {
  SeoAuthor,
  SeoDocument,
  SeoDocumentStatus,
  SeoEntity,
  SeoFaqItem,
} from "./types";

/** Raw row shape from public.seo_documents */
export interface SeoDocumentRow {
  id: string;
  site_id: string;
  slug: string;
  title: string;
  description: string;
  body: string;
  locale: string;
  status: string;
  faq: unknown;
  entities: unknown;
  canonical_path: string | null;
  source_task_id: string | null;
  tags: string[] | null;
  keywords: string[] | null;
  category: string | null;
  image: string | null;
  image_alt: string | null;
  author: unknown;
  word_count: number | null;
  noindex: boolean | null;
  related_slugs: string[] | null;
  quick_answer: string | null;
  created_at: string;
  updated_at: string;
  published_at: string | null;
}

function asFaq(value: unknown): SeoFaqItem[] {
  if (!Array.isArray(value)) return [];
  const out: SeoFaqItem[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const question = typeof row.question === "string" ? row.question : "";
    const answer = typeof row.answer === "string" ? row.answer : "";
    if (question && answer) out.push({ question, answer });
  }
  return out;
}

function asEntities(value: unknown): SeoEntity[] {
  if (!Array.isArray(value)) return [];
  const out: SeoEntity[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const name = typeof row.name === "string" ? row.name : "";
    const type = row.type;
    if (
      !name ||
      (type !== "Product" &&
        type !== "SoftwareApplication" &&
        type !== "Organization" &&
        type !== "Thing")
    ) {
      continue;
    }
    out.push({
      name,
      type,
      description:
        typeof row.description === "string" ? row.description : undefined,
      url: typeof row.url === "string" ? row.url : undefined,
    });
  }
  return out;
}

function asAuthor(value: unknown): SeoAuthor | undefined {
  if (!value || typeof value !== "object") return undefined;
  const row = value as Record<string, unknown>;
  const name = typeof row.name === "string" ? row.name : "";
  if (!name) return undefined;
  return {
    name,
    url: typeof row.url === "string" ? row.url : undefined,
    image: typeof row.image === "string" ? row.image : undefined,
    role: typeof row.role === "string" ? row.role : undefined,
  };
}

function asStatus(value: string): SeoDocumentStatus {
  if (value === "draft" || value === "published" || value === "archived") {
    return value;
  }
  return "draft";
}

export function rowToSeoDocument(row: SeoDocumentRow): SeoDocument {
  return {
    id: row.id,
    siteId: row.site_id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    body: row.body,
    locale: row.locale,
    status: asStatus(row.status),
    faq: asFaq(row.faq),
    entities: asEntities(row.entities),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at ?? undefined,
    canonicalPath: row.canonical_path ?? undefined,
    sourceTaskId: row.source_task_id ?? undefined,
    tags: row.tags ?? undefined,
    keywords: row.keywords ?? undefined,
    category: row.category ?? undefined,
    image: row.image ?? undefined,
    imageAlt: row.image_alt ?? undefined,
    author: asAuthor(row.author),
    wordCount: row.word_count ?? undefined,
    noindex: row.noindex ?? false,
    relatedSlugs: row.related_slugs ?? undefined,
    quickAnswer: row.quick_answer ?? undefined,
  };
}

export function seoDocumentToRow(
  doc: SeoDocument,
): Omit<SeoDocumentRow, "created_at" | "updated_at"> & {
  created_at?: string;
  updated_at?: string;
} {
  return {
    id: doc.id,
    site_id: doc.siteId,
    slug: doc.slug,
    title: doc.title,
    description: doc.description,
    body: doc.body,
    locale: doc.locale,
    status: doc.status,
    faq: doc.faq,
    entities: doc.entities,
    canonical_path: doc.canonicalPath ?? null,
    source_task_id: doc.sourceTaskId ?? null,
    tags: doc.tags ?? [],
    keywords: doc.keywords ?? [],
    category: doc.category ?? null,
    image: doc.image ?? null,
    image_alt: doc.imageAlt ?? null,
    author: doc.author ?? null,
    word_count: doc.wordCount ?? null,
    noindex: doc.noindex ?? false,
    related_slugs: doc.relatedSlugs ?? [],
    quick_answer: doc.quickAnswer ?? null,
    published_at: doc.publishedAt ?? null,
    created_at: doc.createdAt,
    updated_at: doc.updatedAt,
  };
}
