/** SEO/GEO document types — keep in sync with contracts/seo-document.v1.json + site/docs/SEO_GEO_CONTRACT.md */

export interface SiteProfile {
  siteId: string;
  name: string;
  domain: string;
  locale: string;
  defaultTitleTemplate: string;
  defaultDescription: string;
  organization: {
    name: string;
    url: string;
    logoUrl?: string;
    sameAs?: string[];
  };
  productBlurb: string;
  contactEmail?: string;
}

export type SeoDocumentStatus = "draft" | "published" | "archived";

export interface SeoFaqItem {
  question: string;
  answer: string;
}

export interface SeoEntity {
  name: string;
  type: "Product" | "SoftwareApplication" | "Organization" | "Thing";
  description?: string;
  url?: string;
}

/** Optional Person author for Article JSON-LD (falls back to Organization). */
export interface SeoAuthor {
  name: string;
  url?: string;
  image?: string;
  role?: string;
}

export interface SeoDocument {
  id: string;
  siteId: string;
  slug: string;
  title: string;
  description: string;
  body: string;
  locale: string;
  status: SeoDocumentStatus;
  faq: SeoFaqItem[];
  entities: SeoEntity[];
  createdAt: string;
  updatedAt: string;
  publishedAt?: string;
  canonicalPath?: string;
  sourceTaskId?: string;
  tags?: string[];
  /** Focus / meta keywords (optional, v0.2) */
  keywords?: string[];
  /** Primary category / article:section (optional, v0.2) */
  category?: string;
  /** Cover / OG image absolute or site-relative URL (optional, v0.2) */
  image?: string;
  imageAlt?: string;
  author?: SeoAuthor;
  wordCount?: number;
  /** When true, metadata robots = noindex (optional, v0.2) */
  noindex?: boolean;
  /** Related post slugs for internal linking (optional, v0.2) */
  relatedSlugs?: string[];
  /** GEO featured snippet / quick answer (optional, v0.2) */
  quickAnswer?: string;
}

export type SeoActionType =
  | "diagnose"
  | "seed_plan"
  | "generate"
  | "publish"
  | "index"
  | "refresh_gsc";

export type SeoActionStatus =
  | "pending"
  | "running"
  | "succeeded"
  | "failed"
  | "cancelled";

export interface SeoAction {
  id: string;
  siteId: string;
  type: SeoActionType;
  status: SeoActionStatus;
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
  createdAt: string;
  updatedAt: string;
}
