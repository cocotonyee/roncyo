import type { SeoDocument } from "./types";

/**
 * Local demo documents for Starter when Supabase is not wired.
 * Hub remote write (Phase 2) will upsert into seo_documents instead.
 */
export function getDemoSeoDocuments(siteId: string): SeoDocument[] {
  const now = new Date().toISOString();

  return [
    {
      id: "demo-welcome",
      siteId,
      slug: "welcome-to-goship",
      title: "Welcome to GoShip SEO",
      description:
        "How GoShip structures SEO and GEO content so search and AI engines can cite you.",
      body: [
        "# Welcome to GoShip SEO",
        "",
        "GoShip treats structured documents as the source of truth.",
        "Pages render from `SeoDocument` — they are not the only place content lives.",
        "",
        "## Why this matters",
        "",
        "Search engines need crawlable URLs and clear metadata.",
        "Generative engines need quotable facts, FAQs, and consistent entity names.",
        "",
        "## What you get",
        "",
        "- JSON-LD Article + FAQ",
        "- sitemap / robots / llms.txt",
        "- Hub-ready fields for later AI publishing",
      ].join("\n"),
      locale: "en",
      status: "published",
      faq: [
        {
          question: "What is a SeoDocument?",
          answer:
            "A SeoDocument is the canonical content unit shared by Hub writers and Starter renderers.",
        },
        {
          question: "Does GEO replace SEO?",
          answer:
            "No. GEO extends SEO with citation-friendly structure for AI answer engines.",
        },
      ],
      entities: [
        {
          name: "GoShip",
          type: "SoftwareApplication",
          description: "Multi-SaaS matrix hub and pluggable Micro-SaaS SDK",
        },
      ],
      createdAt: now,
      updatedAt: now,
      publishedAt: now,
      tags: ["goship", "seo", "geo"],
    },
  ];
}
